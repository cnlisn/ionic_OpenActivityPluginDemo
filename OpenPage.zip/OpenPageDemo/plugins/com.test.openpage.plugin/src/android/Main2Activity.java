
package com.test.openpage;

import android.app.Activity;
import android.os.Bundle;
import com.ionicframework.openpagedemo934202.R;

public class Main2Activity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
    }
}